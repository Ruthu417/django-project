from django.apps import AppConfig


class CappConfig(AppConfig):
    name = 'capp'
